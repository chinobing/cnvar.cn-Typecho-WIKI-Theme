<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
if (stripos($this->request->getRequestUri(), 'json')) {
    $arr = array();
$this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);
    while ($archives->next()) {
        $a = array('title' => $archives->title, 'date' => $archives->date->format('Y-m-d'), 'discription' => $archives->text, 'tags' => $archives->tags,'url' => $archives->permalink,'category' => $archives->category,);
        $arr[] = $a;
    }
    $this->response->throwJson($arr);
}
?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>

    <!-- 使用url函数转换相关路径 -->
  <!-- Styles --> 
  <link href="<?php $this->options->themeUrl('dist/css/core.css'); ?>" rel="stylesheet" /> 
  <link href="<?php $this->options->themeUrl('dist/css/main.css'); ?>" rel="stylesheet" /> 
  <link href="<?php $this->options->themeUrl('dist/css/global.css'); ?>" rel="stylesheet" />  
  <link href="<?php $this->options->themeUrl('dist/css/inputstyle.css'); ?>" rel="stylesheet" />  
  <link href="<?php $this->options->themeUrl('dist/css/header.css'); ?>" rel="stylesheet" />  
  <link href="<?php $this->options->themeUrl('dist/css/editormd.preview.min.mod.css'); ?>" rel="stylesheet" />  
  <link href="<?php $this->options->themeUrl('dist/css/custom-md.css'); ?>" rel="stylesheet" />  

  <!--[if lt IE 9]>
  <script src="<?php $this->options->themeUrl('dist/js/selectivizr-min.js'); ?>"></script>
  <script src="<?php $this->options->themeUrl('dist/js/html5shiv.min.js'); ?>"></script>
  <script src="<?php $this->options->themeUrl('dist/js/respond.min.js'); ?>"></script>
  <![endif]--> 

    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header(); ?>
</head>
<body>

  <div class="page-wrapper">
   <div class="headband"></div>
   <div class="page-banner-subpage banner-resources p-b-0"> 
    <div class="container"> 

    <header id="header" class="header" itemscope="" itemtype="http://schema.org/WPHeader">
          <div class="header-inner"><div class="site-brand-wrapper">
      <div class="site-meta ">
        <div class="custom-logo-site-title">
          <a href="<?php $this->options->siteUrl(); ?>" class="brand" rel="start">
            <span class="site-title"><?php $this->options->title() ?></span>
          </a>
        </div>
            <h1 class="site-subtitle" itemprop="description">尽职调查 - WIKI</h1>
      </div>
    </header>

     <div class="banner-slogan banner-slogan-hero"> 
      <div class="banner-search"> 
       <form class="search" method="post" onkeyup="return saveInput();" action="<?php $this->options->siteUrl(); ?>"> 
        <div class="input-icon"> 
         <input id="search-input" type="text" name="s" value="" class="form-control input-lg" placeholder="关键字搜索" autocomplete="off" /> 
         <ul class="results" id="results-container"></ul>
         <button type="submit" class="btn btn-link btn-icon btn-lg"><i class="zmdi zmdi-search"></i></button> 
        </div> 
       </form> 
      </div> 
     </div> 
    </div> 
   </div> 
   <!-- /.page-banner -->


  <!-- Script pointing to search-script.js -->
  <script src="<?php $this->options->themeUrl('dist/js/search-script.min.js'); ?>"></script>

<!-- Configuration -->
<script>
SimpleJekyllSearch({
  searchInput: document.getElementById('search-input'),
  resultsContainer: document.getElementById('results-container'),
  json: '/?json'
})

document.getElementById("search-input").value = localStorage.getItem("searchvalue");

function saveInput() {
    var searchvalue = document.getElementById("search-input").value;
    localStorage.setItem("searchvalue", searchvalue);
    return true;
}

</script>

<!-- mark.js-->
<script src="https://libs.baidu.com/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js"></script>
<script>
  $(window).load(function() {
      var markInstance = new Mark(document.querySelector(".doc_content"));
      // Cache DOM elements
      var keywordInput = document.querySelector("input[name='s']");

      function performMark() {

        // Read the keyword
        var keyword = keywordInput.value;

        // Remove previous marked elements and mark
        // the new keyword inside the context
        markInstance.unmark({
          done: function(){
            markInstance.mark(keyword);
          }
        });
      };

      performMark();
      // Listen to input and option changes
      keywordInput.addEventListener("input", performMark);
         
   });
</script>
    
    
