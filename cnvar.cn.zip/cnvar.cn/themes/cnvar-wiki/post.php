<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>


<div class="page-main">
        <div class="container">

            <div class="doc_container">

                <div class="doc_header">
                    <h1><?php $this->title() ?></h1>
                 <div>
                     <span class="post-time">
                        发表于
                        <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date('Y-m-d'); ?></time>
                    </span>


                    <span class="post-category" >
                      &nbsp; | &nbsp; 分类于

                      <span itemprop="about" itemscope itemtype="https://schema.org/Thing">
                       <?php $this->category(' , '); ?>
                   </span>


               </span>

              <span class="post-comments-count">
                &nbsp; | &nbsp;
                <?php if(!empty($this->options->next_comments)): ?>
                <a rel="nofollow" href="<?php $this->permalink() ?>#comments"><span class="ds-thread-count" data-thread-key="<?php echo $this->cid;?>" data-count-type="comments"></span></a>
                <?php else: ?>
                <a rel="nofollow" href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('暂无评论', '1 条评论', '%d 条评论'); ?></a>
                <?php endif; ?>
       </span>

      </div>

                </div>


                <div class="doc_content">
                    


<?php $this->content(); ?>




<?php $this->related(5)->to($relatedPosts); ?>
<?php if ($relatedPosts->have()): ?>
  <h1>相关文章</h1>
  <hr>
<?php endif; ?>
<ul>
<?php while ($relatedPosts->next()): ?>
<li><a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><?php $relatedPosts->title(); ?></a></li>
<?php endwhile; ?>
</ul>

                </div>

                <div class="doc_comments">
    <ul class="post-near">
        <li>上一篇: <?php $this->thePrev('%s','没有了'); ?></li>
        <li>下一篇: <?php $this->theNext('%s','没有了'); ?></li>
    </ul>

                <?php $this->need('comments.php'); ?>

                </div>

            </div>

        </div>
    </div>


<?php $this->need('footer.php'); ?>
