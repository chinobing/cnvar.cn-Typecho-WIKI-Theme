<?php
/**
* index
*
* @package custom
*/

$this->need('header.php'); ?>

<div id="panel-block" class="container panel panel-block">
    <div class="container">
        <div class="tags-wrapper" >
            <?php $this->widget('Widget_Metas_Tag_Cloud', 'sort=mid&ignoreZeroCount=1&desc=0')->to($tags); ?>
            <?php if($tags->have()): ?>
            <div class="tags-list">
                <?php while ($tags->next()): ?>
                    <div class="col-md-2 tag-item"><a href="<?php $tags->permalink(); ?>" rel="tag" class="size-<?php $tags->split(5, 10, 20, 30); ?>" title="<?php $tags->count(); ?> 个话题"><?php $tags->name(); ?> (<?php $tags->count(); ?>)</a></div>
                <?php endwhile; ?>
                <?php else: ?>
                    <div><?php _e('没有任何标签'); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div><!-- end #main-->
</div>

<div> 
    <div class="container"> 
     <div class="main-content"> 
      <div class="content-row"> 
       <div class="blocks row"> 

<?php $this->widget('Widget_Metas_Category_List')->to($categories); ?>
<?php while ($categories->next()): ?>


        <div class="col-sm-6"> 
         <div class="panel-block"> 
          <h2 class="panel-title h3"><a href="<?php $categories->permalink(); ?>"><?php $categories->name(); ?></a></h2> 
          <ul class="list-styled list-icon article_list"> 
           
<?php $this->widget('Widget_Archive@category-' . $categories->mid, 'pageSize=50&type=category', 'mid=' . $categories->mid)->to($posts); ?>

<?php while ($posts->next()): ?>

<li><a data-toggle="collapse" data-target="#<?php $posts->cid(); ?>"><i class="zmdi zmdi-file-text"></i></a><a target="_blank" href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a><p id="<?php $posts->cid(); ?>" class="list-styled list-icon article_list collapse"><?php $posts->tags('', true, '暂无标签分类'); ?></p></li>




<?php endwhile; ?>

          </ul> 
         </div> 
        </div> 
      
<?php endwhile; ?>
        

        
        
       </div> 
      </div> 
     </div> 
    </div> 
   </div>




   <div>
    <div class="container">
     <div class="main-content">
      <div class="content-row">
       <div class="blocks row">

        <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
        <?php while($pages->next()): ?>
        <div class="col-sm-12">
         <div class="panel panel-default">
          <h2 class="panel-heading h3"><a data-toggle="collapse" data-target="#<?php $pages->slug(); ?>" href="#<?php $pages->slug(); ?>"><?php $pages->title(); ?></a></h2>
          <div id="<?php $pages->slug(); ?>" class="list-styled list-icon article_list collapse">
             <?php $pages->content(); ?>
          </div>
         </div>
        </div>
       <?php endwhile; ?>

       </div>
      </div>
     </div>
    </div>
   </div>



<?php $this->need('footer.php'); ?>
