<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>



   <div class="page-footer"> 
    <footer class="footer-bottom"> 
     <div class="container"> 
      <div class="row"> 
       <div class="col-lg-6 col-lg-push-6 col-xs-12"> 
        <ul class="nav"> 
         <li class="hidden-xs"><a href="https://www.f10.org/" target="_blank">F10-基本面分析</a></li> 
         <li><a href="https://www.chaqi.net" target="_blank"">查企.Net</a></li>
         <li><a href="https://www.cnVaR.cn" target="_blank"">cnVaR - 风险价值</a></li> 
        </ul> 
        <ul class="social"> 
         <li><a href="#" class="btn btn-primary btn-circle btn-icon btn-outline btn-sm"><i class="zmdi zmdi-home"></i></a></li> 
         <li><a href="#" class="btn btn-primary btn-circle btn-icon btn-outline btn-sm"><i class="zmdi zmdi-inbox"></i></a></li> 
        </ul> 
       </div> 
       <div class="col-lg-6 col-lg-pull-6 col-xs-12"> 
        <p class="footer-copyright"> Copyright 2019 &copy; 柯西君_BingWong. All rights reserved. </p> 
        <small>“All I Want To Know Is Where I'm Going To Die. So I'll Never Go There” –  Buffett & Munger</small>
        <small>cnvar.cn#gmail.com</small>

       </div> 
      </div> 
     </div> 
    </footer> 
   </div> 
   <!-- /.page-footer --> 




</footer><!-- end #footer -->


  </div class="page-wrapper">

<script src="<?php $this->options->themeUrl('dist/js/jquery.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('dist/js/core.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('dist/js/main.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('dist/js/editormdSupport.js'); ?>"></script>


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-105783251-4', 'auto');
  ga('send', 'pageview');
</script>
<?php $this->footer(); ?>
</body>
</html>
