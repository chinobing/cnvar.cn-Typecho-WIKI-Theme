<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="block_message me404" style="margin-top: 80px;">
        <div class="container">
                            <div class="base_message error_message custom_message">404 Error - Article no longer exists.</div>
                    </div>
    </div>


	<?php $this->need('footer.php'); ?>
